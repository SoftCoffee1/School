//
//  main.c
//  20181288
//
//  Created by 윤성호 on 2022/05/27.
//

// 2022. 05.27 2 24 ~ 2 44
// 2022. 05.27 3 10 ~

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define max(a,b) (((a) > (b)) ? (a) : (b))
#define min(a,b) (((a) < (b)) ? (a) : (b))

/* 전역 변수 */
int N; // 미로의 가로 사이즈
int M; // 미로의 세로 사이즈

int *prevMAZE; // 미로의 바로 직전 행의 정보를 저장하기 위해 선언
int *nowMAZE; // 미로의 현재 행의 정보를 저장하기 위해 선언

int *TYPES; // 집합의 종류를 저장하는 배열
int *COUNT; // 각 집합의 개수를 저장하는 배열
int *INDEX; // 각 집합의 TYPES 배열에서의 인덱스를 저장하는 배열
int *CONNECTED; // 각 집합이 수직으로 연결되어 있는 것의 여부를 저장하는 배열

int connected; //
int types = 1; // 종류의 개수를 저장
int roomNum = 1; // 방번호는 1부터 시작한다.

FILE *fp; // 텍스트 파일을 생성하기 위한 파일 포인터

void horizontalCheck(int); // 수평연결과정을 처리하는 함수
void verticalCheck(int); // 수직연결과정을 처리하는 함수

int main(void) {
    
    srand((unsigned int)time(NULL)); // 무작위로 연결여부를 선택하기 위해 시드넘버를 변화시켜주는 부분
    
    scanf("%d", &N); // 미로의 가로 사이즈를 입력받는다.
    scanf("%d", &M); // 미로의 세로 사이즈를 입력받는다.
    
    fp = fopen("20181288.maz", "w"); // 20181288.maz 파일을 생성하고, 이미 있다면 새롭게 다시 쓴다.
    
    if (fp == NULL){
        printf("File open Error"); // 파일이 존재하지 않는다면 에러메세지를 출력한다.
        exit(1); // 프로그램을 종료한다.
    }
    
    else{
        printf("파일이 생성되었습니다.\n"); // 파일이 성공적으로 생성되었다면 성공했다는 메세지를 출력한다.
    }
    
    prevMAZE = calloc(N,sizeof(int*)); // 동적할당으로 미로 행 배열 정의, 0으로 초기화.
    nowMAZE  = calloc(N,sizeof(int*)); // 동적할당으로 미로 행 배열 정의, 0으로 초기화.
    
    // 가장 꼭대기 지점은 모두 벽으로 가로막혀있다.
    for (int i = 0 ; i <= 2*N; i++){
        
        // 짝수지점은 모서리이므로 +를 출력한다.
        if (i%2 == 0) {
            //printf("+");
            fprintf(fp, "+");
        }
        
        // 홀수지점은 모서리가 아니므로 벽(-)을 출력한다.
        else {
            //printf("-");
            fprintf(fp, "-");
        }
    }
    
    // 다음 칸에 미로를 출력해주기 위해 newline을 출력해준다.
    //printf("\n");
    fprintf(fp, "\n");
    
    
    /* 수평 과정 */
    for (int line = 0; line < M; line++){
        
        horizontalCheck(line); // 현재 확인하고 있는 행에 대해 수평 연결을 처리해준다.
         
        
        TYPES = malloc(types*sizeof(int)); // 집합의 종류를 저장할 배열
        COUNT = calloc(types,sizeof(int)); // 집합의 종류의 개수를 저장할 배열
        INDEX = malloc((N*M+1)*sizeof(int)); // 동적할당으로 인덱스를 저장할 배열 정의.
        
        for (int i = 1; i <= N*M; i++) INDEX[i] = -1; // 집합의 인덱스는 -1로 초기화해준다.
        
        int tIndex = 0; // TYPES에 값을 저장할 때 필요한 변수
        for (int i = 0; i < N; i++){
            
            // 아직 종류를 등록하지 않았다면
            if (INDEX[nowMAZE[i]] == -1){
                INDEX[nowMAZE[i]] = tIndex; // INDEX 배열에 값을 저장한다.
                TYPES[tIndex++] = nowMAZE[i]; // TYPES 배열에 현재 집합의 번호를 저장한다.
            }
            
            COUNT[INDEX[nowMAZE[i]]]++; // COUNT 배열의 값을 1 증가시킨다.
        }
        
        for (int i = 0; i < N; i++){
            prevMAZE[i] = nowMAZE[i]; // 이전 행으로 옮겨주고
            nowMAZE[i] = 0; // 현재 행은 초기화해준다.
        }
        
        // 다음칸에 미로를 출력해주어야하기 때문에 newline을 출력해준다.
        //printf("\n");
        fprintf(fp, "\n");
        
        
        /* 수직 과정 */
        verticalCheck(line); // 수직연결을 처리해준다.
        
        // 다음줄에 미로를 출력해주기 위해 newline을 출력해준다.
        //printf("\n");
        fprintf(fp, "\n");
        
    }
    
    // 파일을 닫아준다.
    fclose(fp);
    
    return 0;
}


// 수평과정을 처리하는 함수
void horizontalCheck(int line){
    
    // 집합번호가 배정이 되어 있지 않은 칸은 전역변수로 저장된 roomNum을 이용해 매번 다른 수로 번호를 매겨준다.
    for(int i = 0 ; i < N; i++){
        if (nowMAZE[i] == 0) nowMAZE[i] = roomNum++;
    }
    
    types = 1; // 현재 행에서 탐색하는 집합의 개수를 1로 초기화해준다.
    
    // 행을 모두 살펴보며
    for (int i = 0; i <= N; i++){
        
        // 시작 지점은 항상 벽이다. 벽의 모양은 "|" 이다.
        if (i == 0){
            //printf("| ");
            fprintf(fp, "| ");
            continue; // for loop의 처음부분으로 돌아간다.
        }
        
        // 끝 지점은 항상 벽이다. 벽의 모양은 "|" 이다.
        if (i == N){
            //printf("|");
            fprintf(fp,"|");
            break; // for loop를 탈출한다.
        }
        
        // 만약 마지막 줄이라면
        if (line == M-1){
            
            // 인접한 칸의 집합번호가 다르다면 경로가 없다는 것을 의미하므로 무조건 연결을 해주어야 한다.
            if (nowMAZE[i - 1] != nowMAZE[i]){
                
                int nowMin = min(nowMAZE[i - 1] ,nowMAZE[i]); // 인접한 두 칸의 번호 중 작은 번호
                int nowMax = max(nowMAZE[i - 1] ,nowMAZE[i]); // 인접합 두 칸의 번호 중 큰 번호
                
                // 집합 연결시켜주기. 행 전체를 돌며 nowMax와 같은 집합번호를 가지고 있는 칸은 nowMin으로 변경해준다.
                for (int same = 0; same<N; same++)
                    if (nowMAZE[same] == nowMax) nowMAZE[same] = nowMin;
                
                // 방이 연결되었기 때문에 공백을 출력해준다.
                //printf("  ");
                fprintf(fp, "  ");
            }
            
            // 방이 연결되어있지 않다면 벽을 출력해준다. 벽은 "|"모양이다.
            else{
                //printf("| ");
                fprintf(fp, "| ");
            }
        }
        
        
        // 만약 현재 확인하는 행이 마지막 줄이 아니라면
        else if (line < M-1){
            connected = rand()%2; // 연결 할지 말지 무작위로 선택한다.
            
            // 아직 연결이 되어 있지 않으면서 연결을 시켜주려고 할 때 -> 이미 연결이 되어있으면 연결시켜주면 안된다.
            if (connected == 1 && (nowMAZE[i - 1] != nowMAZE[i])){
                
                int nowMin = min(nowMAZE[i - 1] ,nowMAZE[i]); // 인접한 두 칸의 번호 중 작은 번호
                int nowMax = max(nowMAZE[i - 1] ,nowMAZE[i]); // 인접한 두 칸의 번호 중 큰 번호
                
                // 집합 연결시켜주기. 행 전체를 돌며 nowMax와 같은 집합번호를 가지고 있는 칸은 nowMin으로 변경해준다.
                for (int same = 0; same<N; same++)
                    if (nowMAZE[same] == nowMax) nowMAZE[same] = nowMin;
                
                // 방이 연결되어 있으므로 공백을 출력해준다.
                //printf("  ");
                fprintf(fp, "  ");
            }
            
            // 방이 연결되어있지 않거나, 연결을 하지 않는 것으로 결정을 했다면
            else{
                // 벽을 출력한다. 벽은 "|" 모양이다.
                //printf("| ");
                fprintf(fp, "| ");
                types++; // 집합의 개수를 하나 증가시켜준다.
            }
        }
    }
}



void verticalCheck(int line){
    
    // 마지막 행을 탐색하고 있다면
    if (line == M-1){
        for (int i = 0 ; i <= 2*N; i++){
            
            // 짝수지점은 모서리이므로 +를 출력한다.
            if (i%2 == 0) {
                //printf("+");
                fprintf(fp, "+");
            }
            
            // 홀수지점은 모서리가 아니므로 벽(-)을 출력한다.
            else {
                //printf("-");
                fprintf(fp, "-");
            }
        }
        
        // 마지막 행의 처리까지 끝났으므로 함수를 종료한다.
        return;
    }
    
    // 아래행과 집합의 연결여부를 저장하는 배열이다. 0으로 초기화한다.
    CONNECTED = calloc(types,sizeof(int));
    
    for (int i = 0 ; i <= 2*N; i++){
        
        // 짝수지점은 모서리이므로 +를 출력한다.
        if (i%2 == 0) {
            //printf("+");
            fprintf(fp, "+");
        }
        
        // 홀수지점은 벽일수도 아닐 수 도 있다.
        else {
            
            // 현재 집합이 이전 행에 하나밖에 없는데 아직 연결이 되어있지 않다면 무조건 연결을 시켜주어야한다.
            if (COUNT[INDEX[prevMAZE[i/2]]] == 1 && CONNECTED[INDEX[prevMAZE[i/2]]] == 0){
                nowMAZE[i/2] = prevMAZE[i/2]; // 이전 행의 집합번호를 현재 행의 집합번호가 되게 한다.
                CONNECTED[INDEX[prevMAZE[i/2]]] = 1; // 현재 집합은 아래 행과 연결되어있으므로 1로 변경해준다.
                COUNT[INDEX[prevMAZE[i/2]]]--; // 현재 탐색 중인 집합번호의 개수는 1 줄여준다.
                //printf(" "); // 연결이 되어 있으므로 공백을 출력해준다.
                fprintf(fp, " ");
            }
            
            // 현재 집합이 이전 행에 하나 이상 있으면 연결을 해줄 수도 있고 해주지 않을 수도 있다.
            else if (COUNT[INDEX[prevMAZE[i/2]]] >= 1) {
                connected = rand()%2;
                
                // 연결을 해준다고 결정을 했다면
                if (connected == 1){
                    nowMAZE[i/2] = prevMAZE[i/2]; // 이전 행의 집합 번호가 현재 행의 집합번호가 되게 한다.
                    CONNECTED[INDEX[prevMAZE[i/2]]] = 1; // 현재 집합은 아래 행과 연결되어있으므로 1로 변경해준다.
                    //printf(" "); // 연결되었기 때문에 공백을 출력해준다.
                    fprintf(fp, " ");
                }
                
                // 연결을 하지 않는다고 결정을 했다면
                else{
                    //printf("-"); // 벽을 그려준다. 벽은 "-" 모양이다.
                    fprintf(fp, "-");
                }
                
                // 현재 탐색하는 집합번호의 개수를 1 줄여준다.
                COUNT[INDEX[prevMAZE[i/2]]]--;
            }
        }
    }
}
