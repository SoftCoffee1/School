#include<stdio.h>
#include<stdlib.h>


void Count ( int **arr, int testcase, int n );
void countEach(int** arr, int testcase, int n, int times);
void printArr ( int **arr, int n );
