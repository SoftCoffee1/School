﻿echo 'Working directory'
read dirname

if [ -n $dirname ]
then
    # if the input directory exists
    if [ -d $dirname]
    then
        # if we can cd
        if [ -x $dirname ]
        then
            # if dir has write permission(We need write permission to rename dir.)
            if [ -w $dirname ]
            then
                cd $dirname
            else
                echo "Error : cannot rename files because directory has no w permission"
                exit 1
            fi
        else
            echo "Error : cannot change directory"
            exit 1
        fi
    else
        echo "Error : directory doesn't exist"
        exit 1
    fi
fi
for dir in *
do
    newname=`echo $dir | tr "[a-z] [A-Z]" "[A-Z] [a-z]"` 
    mv $dir $newname
done